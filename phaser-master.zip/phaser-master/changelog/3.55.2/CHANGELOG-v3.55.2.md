# Phaser 3 Change Log

## Version 3.55.2 - Ichika - 27th May 2021

### Bug Fixes

* Fixed an issue in `FillPathWebGL`, `IsoBoxWebGLRenderer` and `IsoTriangleWebGLRenderer` functions which caused the filled versions of most Shape Game Objects to pick-up the texture of the previous object on the display list. Fix #5720 (thanks @samme)
